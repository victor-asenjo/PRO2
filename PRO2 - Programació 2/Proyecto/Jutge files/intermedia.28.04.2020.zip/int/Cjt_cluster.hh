/** @file Cjt_cluster.hh
    @brief Especificación de la clase Cjt_cluster
*/

#ifndef CONJ_CLUS_HH
#define CONJ_CLUS_HH

#include "Cluster.hh"
#include "Cjt_especies.hh"

using namespace std; 

/**
  @class Cjt_cluster
  @brief Tipo de módulo: datos.
  @brief Descripción del tipo: representa un conjunto de clusters que se pueden consultar y modificar sus elementos (de tipo Cjt_especies).
*/

class Cjt_cluster
{

private:
    typedef map<string, Cluster> clusters;

public:

  /* Constructoras */

  /**
  @brief Constructora Cjt_cluster.
  \pre Cierto.
  \post El resultado es un conjunto de clusters vacío.
  */
  Cjt_cluster();

  /* Destructora */

  /**
  @brief Destructora Cjt_cluster.
  */
  ~Cjt_cluster();
   

  /* Modificadoras */
  
  /**
  @brief Inicializa el conjunto de clústers con el conjunto de especies en el estado en el que esté en ese momento, e imprime los clústers resultantes, así como la tabla de distancias entre clústers. Al imprimir la tabla de distancias se usarán los identificadores de los clústers para indexar filas y columnas. Si el conjunto es vacío, no imprime ninguna información.
  \pre Cierto.
  \post Inicializa el conjunto de clústers con el conjunto de especies en el estado en el que esté en ese momento e impime los clústers, la tabla de distancias entre clústers.
  */
  void inicializa_clusters(Cjt_especies cjt_esp);

/**
  @brief Ejecuta un paso del algoritmo WPGMA (fusiona los dos clústers a menor distancia en uno nuevo) e imprime la tabla de distancias entre clústers resultante. Al imprimir la tabla de distancias se usarán los identificadores de los clústers para indexar filas y columnas. En caso de que el número de clústers del conjunto sea menor o igual que uno solamente se debe imprimir un mensaje de error.
  \pre Cierto.
  \post Ejecuta un paso del algoritmo e imprmie la tabla de distancias entre clústers resultante.
*/
  void ejecuta_paso_wpgma();

/**
  @brief Ejecuta por completo el algoritmo WPGMA.
  \pre Cierto.
  \post Ejecuta por completo el algoritmo.
*/
  void ejecuta_wpgma();  
    
  /* Lectura y escritura */

/**
  @brief Dado un identificador α, imprime el clúster (su “estructura arborescente”) con el identificador dado, o un error si no existe un clúster con dicho identificador en el conjunto de clústers.
  \pre Cierto.
  \post Se ha escrito por el canal estándar de salida el clúster con el identificador dado.
*/
  void imprime_cluster(string id);

/**
  @brief Imprime todos los clústers.
  \pre Cierto.
  \post Se ha escrito por el canal estándar de salida todos los clústers.
*/
  void imprime_clusters();

/**
  @brief Imprime la tabla de distancias entre clústers.
  \pre Cierto.
  \post Se ha escrito por el canal estándar de salida la tabla de distancias.
*/
  void imprime_tabla_distancias();

/**
  @brief Imprime el árbol filogenético para el conjunto de especies actual; dicho árbol es el clúster que agrupa todas las especies, resultante de aplicar el algoritmo WPGMA. El contenido del conjunto de clústers previo se descarta y se reinicializa con el conjunto de especies en el estado en el que esté en ese momento, para a continuación aplicar el algoritmo. El conjunto de clústers final es el que queda después de aplicar el algoritmo. Se imprimirá la estructura arborescente del clúster con los identificadores de los clústers (raíces de los subárboles) y la distancia entre cada clúster y sus hojas descendientes (véase la figura 3; dichas distancias son los números a la izquierda, y se pueden calcular fácilmente a partir de la distancia entre los clústers cuya combinación da origen a cada clúster). El formato preciso en el que se ha de imprimir el árbol se mostrará en los juegos de pruebas públicos. Si el nuevo conjunto de clústers es vacío, solamente se ha de escribir un mensaje de error.
  \pre Cierto.
  \post Se ha escrito por el canal estándar de salida el árbol filogenético para el conjuntode especies actual después de aplicar el algoritmo WPGMA.
*/
  void imprime_arbol_filoge();
};
#endif