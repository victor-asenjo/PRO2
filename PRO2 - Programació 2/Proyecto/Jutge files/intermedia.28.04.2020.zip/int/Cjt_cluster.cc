#include "Cjt_cluster.hh"

#include <iostream>
#include <algorithm>

Cjt_cluster::Cjt_cluster()
{
}
  
Cjt_cluster::~Cjt_cluster()
{
}

void Cjt_cluster::inicializa_clusters(Cjt_especies especies)
{
    Cjt_especies e = especies;
}

void Cjt_cluster::imprime_tabla_distancias()
{
    
}

void Cjt_cluster::imprime_cluster(string id)
{
    id = "";
}

void Cjt_cluster::imprime_clusters()
{
    
}

void Cjt_cluster::ejecuta_paso_wpgma()
{
    
}

void Cjt_cluster::imprime_arbol_filoge()
{
    
}
