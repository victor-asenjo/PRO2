/** 
    @file Especie.hh
    @brief Especificación de la clase Especie
*/

#ifndef ESPECIE_HH
#define ESPECIE_HH

#ifndef NO_DIAGRAM
#include <string>
#include <vector>
#include <map>
#endif

using namespace std;

/**
    @class Especie
    @brief Tipo de módulo: datos.
    @brief Descripción del tipo: contiene el identificador y el gen de cada especie que son strings.
*/

class Especie
{

private:
    string id;
    string gen;

    typedef map<string, int> Meros;
    Meros meros;

    /* Estáticas */
    static int k;
	  
public:
    /* Constructoras */

    /**
    @brief Constructora Especie vacía.
    \pre Cierto.
    \post El resultado es una especie sin parámetros.
    */
    Especie();

	/**
	@brief Constructora Especie.
	\pre Cierto.
	\post El resultado es una especie con el id y gen proporcionados.
	*/
	Especie(string id, string gen);

	/**
	@brief Destructora Especie. 
	*/
	~Especie();
	  
    /* Estáticas */
    
    static void modifica_k(int k);
    
    static int consulta_k();
  
    /* Consultoras */
    
	/**
	@brief Consultar id de una especie "e".
	\pre Cierto.
	\post El resultado es el id del parámetro implícito.
	*/
	string consultar_id() const;

	/**
	@brief Consultar id de una especie "e".
	\pre Cierto.
	\post El resultado es el gen del parámetro implícito.
	*/
	string consultar_gen() const;

    /* Modificadoras */
    
    
	/* Cálculo */

	void generar_meros();

	int num_meros();

	int ocurrencias_mero(string mero);

	/**
	@brief A partir de dos especies calcula la distancia que hay entre ellas.
	\pre Cierto.
	\post El distancia a otra especie desde el parámetro implícito.
	*/
	double distancia(Especie& other);

	/* Lectura y escritura */
	
	/**
	@brief Lee por el canal estándar de entrada una especie (par identificador-gen).
	\pre Cierto.
	\post 
	*/
	void lee();

	/**
	@brief Imprime la especie del parámetro implícito.
	\pre Cierto.
	\post Se ha escrito por el canal estándar de salida la especie del parámetro implícito.
	*/ 
	void imprime() const;
    
    void imprime_meros() const;
};

#endif
