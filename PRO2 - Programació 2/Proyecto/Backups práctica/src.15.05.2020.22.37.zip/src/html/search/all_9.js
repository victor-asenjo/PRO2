var searchData=
[
  ['nuevo_5fcluster',['nuevo_cluster',['../class_cjt__clusters.html#aaa01a942181881d0fe669ea213c11597',1,'Cjt_clusters']]],
  ['num_5fmeros',['num_meros',['../class_especie.html#a9ba7f669d9c85508e57f7e0fdfe9fd0a',1,'Especie']]]
];
