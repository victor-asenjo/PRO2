var searchData=
[
  ['distancia',['distancia',['../class_cluster.html#aae1191b1d874e512e051175da881b693',1,'Cluster']]],
  ['distancias',['distancias',['../class_cjt__clusters.html#ac9108852bec0fc02b421aa3390f99f40',1,'Cjt_clusters']]]
];
