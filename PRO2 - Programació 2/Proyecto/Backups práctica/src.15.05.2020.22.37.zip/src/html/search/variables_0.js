var searchData=
[
  ['cluster_5factual',['cluster_actual',['../class_cjt__clusters.html#a368344304357ad10bdd15f58cb61b2c1',1,'Cjt_clusters']]],
  ['clusters',['clusters',['../class_cjt__clusters.html#a13df2ecdb1bdc2d7f0adf132faf89043',1,'Cjt_clusters']]],
  ['clusters_5factivos',['clusters_activos',['../class_cjt__clusters.html#a75bbadeb067d43a3daf79978e1ecb72b',1,'Cjt_clusters']]],
  ['clusters_5fambos',['clusters_ambos',['../class_cjt__clusters.html#ad166aaca6306e792f3facd48f96ff310',1,'Cjt_clusters']]],
  ['clusters_5fcomplejos',['clusters_complejos',['../class_cjt__clusters.html#a9ccb9f797fddae233fddc4b8471d5f3d',1,'Cjt_clusters']]],
  ['clusters_5fsencillos',['clusters_sencillos',['../class_cjt__clusters.html#aa7a3a7f9a1459548c5ce843b3b8709ab',1,'Cjt_clusters']]]
];
