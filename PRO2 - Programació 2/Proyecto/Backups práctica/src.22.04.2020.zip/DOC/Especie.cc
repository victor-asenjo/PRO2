#include "Especie.hh"
#include <iostream>

Especie::Especie(){}

Especie::Especie(string id, string gen)
{
  this->id = id;
  this->gen = gen;
}

Especie::~Especie(){}

string Especie::consultar_id() const
{
  return id;
}

string Especie::consultar_gen() const
{
  return gen;
}

double Especie::distancia(Especie& other, int k){}


void Especie::imprime() const
{
    cout << id << " " << gen << endl;
}
