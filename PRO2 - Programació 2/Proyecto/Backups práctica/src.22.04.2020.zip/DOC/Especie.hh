/** @file Especie.hh
    @brief Especificación de la clase Especie
*/

#ifndef ESPECIE_HH
#define ESPECIE_HH

#ifndef NO_DIAGRAM
#include <string>
#include <vector>
#endif

using namespace std;

/**
    @class Especie
    @brief Tipo de módulo: datos.
    @brief Descripción del tipo: contiene el identificador y el gen de cada especie que son strings.
*/

class Especie {
    
private:
  string id;
  string gen;
    
public:
  /* Constructoras */

/**
  @brief Constructora Especie vacía.
  \pre Cierto.
  \post El resultado es una especie sin parámetros.
  */
  Especie();

  /**
  @brief Constructora Especie.
  \pre Cierto.
  \post El resultado es una especie con el id y gen proporcionados.
  */
  Especie (string id, string gen);

  /**
  @brief Destructora Especie. 
  */
  ~Especie();
    
  /* Consultoras */

  /**
  @brief Consultar id de una especie "e".
  \pre Cierto.
  \post El resultado es el id del parámetro implícito.
  */
  string consultar_id() const;

  /**
  @brief Consultar id de una especie "e".
  \pre Cierto.
  \post El resultado es el gen del parámetro implícito.
  */
  string consultar_gen() const;

  /* Cálculo */

  /**
  @brief A partir de dos especies calcula la distancia que hay entre ellas.
  \pre Cierto.
  \post El distancia a otra especie desde el parámetro implícito.
  */
 double distancia(Especie& other, int k);

  /* Escritura */
  
  /**
  @brief Imprime la especie del parámetro implícito.
  \pre Cierto.
  \post Se ha escrito por el canal estándar de salida la especie del parámetro implícito.
  */ 
  void imprime() const;
};
#endif