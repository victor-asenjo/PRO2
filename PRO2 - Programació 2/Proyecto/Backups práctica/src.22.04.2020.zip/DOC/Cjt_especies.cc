#include "Cjt_especies.hh"
#include <iostream>
#include <algorithm>


Cjt_especies::Cjt_especies() {}
  
Cjt_especies::~Cjt_especies() {}
 
void Cjt_especies::anyadir_especie(const string& id, const string& gen)
{
  if (existe_especie(id))
      cout << "Error: la especie ya existe en el conjunto";
  
  else
  {
      Especie e(id, gen);
      especies[id] = e;
  }
}

double Cjt_especies::distancia(string id1, string id2, int k){}


void Cjt_especies::elimina_especie(const string id)
{
    if (not existe_especie(id))
        cout << "Error: la especie no existe en el conjunto";
    
    else
    {
        especies.erase(id);
    }
}

void Cjt_especies::vaciar_cjt()
{
    especies.clear();
}

string Cjt_especies::obtener_gen(string id) const
{
    if (not existe_especie(id))
    {
        cout << "Error: la especie con el identificaodr dado, no existe en el conjunto";
        return "";
    }

    else
    {
        Especies::const_iterator it;
        it = especies.find(id);
        return it->second.consultar_gen();
    }
}

bool Cjt_especies::existe_especie(string id) const
{
    Especies::const_iterator it;
    it = especies.find(id);
    return (it != especies.end());
}

void Cjt_especies::lee_especie()
{
    string id, gen;
    cin >> id >> gen;
    anyadir_especie(id, gen);
}

void Cjt_especies::lee_cjt_especies()
{
    vaciar_cjt();
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        lee_especie();
    }
}

void Cjt_especies::imprime_cjt_especies() const
{
    Especies::const_iterator it;
    for(it = especies.begin(); it != especies.end(); ++it)
    {
        it->second.imprime();
    }
}

void Cjt_especies::imprime_t_dist() const{}
