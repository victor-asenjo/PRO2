#include "Cjt_cluster.hh"
#include <iostream>
#include <algorithm>


Cjt_cluster::Cjt_cluster() {}
  
Cjt_cluster::~Cjt_cluster() {}