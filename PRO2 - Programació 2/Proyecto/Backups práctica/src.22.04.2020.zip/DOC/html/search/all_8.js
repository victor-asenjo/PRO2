var searchData=
[
  ['obtener_5fgen',['obtener_gen',['../class_cjt__especies.html#a65ddc42fcccc8b7a11c10756a454c336',1,'Cjt_especies']]]
];
