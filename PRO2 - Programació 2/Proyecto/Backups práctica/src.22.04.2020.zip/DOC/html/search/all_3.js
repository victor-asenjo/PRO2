var searchData=
[
  ['distancia',['distancia',['../class_cjt__especies.html#a04d7c02ee5915109e5dcf3411b1ddeff',1,'Cjt_especies::distancia()'],['../class_especie.html#ad5d693cc20a727b85ce160352229592c',1,'Especie::distancia()']]]
];
