#include "Cluster.hh"
#include <iostream>

Cluster::Cluster(){}

Cluster::~Cluster(){}