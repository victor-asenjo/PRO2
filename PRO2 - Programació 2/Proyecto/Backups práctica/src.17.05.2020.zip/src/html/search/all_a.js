var searchData=
[
  ['obtener_5fgen',['obtener_gen',['../class_cjt__especies.html#a65ddc42fcccc8b7a11c10756a454c336',1,'Cjt_especies']]],
  ['obtener_5fids',['obtener_ids',['../class_cjt__especies.html#af92d5f22a6c469d0fa330f49185a4491',1,'Cjt_especies']]],
  ['ocurrencias_5fmero',['ocurrencias_mero',['../class_especie.html#ab669d4c3eaaee9bc4a618715323c91ad',1,'Especie']]]
];
