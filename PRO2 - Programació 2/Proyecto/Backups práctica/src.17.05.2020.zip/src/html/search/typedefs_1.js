var searchData=
[
  ['mapa',['Mapa',['../class_cjt__clusters.html#a97e7e413841b9155da950e779753950e',1,'Cjt_clusters']]],
  ['meros',['Meros',['../class_especie.html#af68be96e3b46f3f982409773cb5b603e',1,'Especie']]]
];
