var indexSectionsWithContent =
{
  0: "acdegiklmnopuv~Ã",
  1: "ce",
  2: "cep",
  3: "acdegilmnopuv~",
  4: "cdegikm",
  5: "em",
  6: "Ã"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "Páginas"
};

