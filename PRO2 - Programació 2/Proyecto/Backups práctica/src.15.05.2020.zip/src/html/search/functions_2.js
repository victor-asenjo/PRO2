var searchData=
[
  ['distancia',['distancia',['../class_cjt__especies.html#a7cad69527c7c8a462a4ffdd11eb508f5',1,'Cjt_especies::distancia()'],['../class_especie.html#a3170fb0ddb094f93071c6172b625dec0',1,'Especie::distancia()']]]
];
