var searchData=
[
  ['meros',['meros',['../class_especie.html#aa2694dbdfab27f2f960662371f0bd2e9',1,'Especie']]]
];
