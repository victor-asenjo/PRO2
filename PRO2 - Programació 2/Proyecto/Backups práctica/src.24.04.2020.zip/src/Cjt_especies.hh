/**
    @file Cjt_especies.hh
    @brief Especificación de la clase Cjt_especies
*/

#ifndef CONJ_ESP_HH
#define CONJ_ESP_HH

#include "Especie.hh"

#ifndef NO_DIAGRAM
#include <map>
#endif

using namespace std;

/**
	@class Cjt_especies
	@brief Tipo de módulo: datos.
	@brief Descripción del tipo: representa un conjunto de especies que se pueden consultar y modificar sus elementos (de tipo Especie).
*/

class Cjt_especies
{

private:
    typedef map<string, Especie> Especies;
    Especies especies;

public:

	/* Constructoras */

	/**
	@brief Constructora Cjt_especies.
	\pre Cierto.
	\post El resultado es un conjunto de especies vacío.
	*/
	Cjt_especies();

	/* Destructora */

	/**
	@brief Destructora Cjt_especies.
	*/
	~Cjt_especies();
	 

	/* Modificadoras */

	/**
	@brief Añadir especie al conjunto.
	\pre El parámetro implícito no contiene ninguna especie con el identificador dado.
	\post Se ha añadido la especie "e" al parámetro implícito.
	*/
    void anyadir_especie(const string& id, const string& gen);

	/**
	@brief Eliminar especie del conjunto.
	\pre El parámetro implícito contiene una especie con el identificador dado.
	\post Se ha eliminado la especie "e" del parámetro implícito.
	*/
	void elimina_especie(const string id);
 
	/**
	@brief Vacía conjunto de especies.
	\pre Hay un conjunto de especies no vacío.
	\post Devuelve un conjunto de especies vacío.
	*/
	void vaciar_cjt();
	
	
	/* Consultoras */
	
	/**
	@brief Obtener gen.
	\pre El id proporcionado existe, de lo contrario devolverá un error.
	\post El resultado es el gen asociado a la especie.
	*/
	string obtener_gen(string id) const;

	/**
	@brief ¿Existe alguna especie con este ID?.
	\pre Cierto.
	\post El resultado indica si existe una especie en el parametro implícito con ID = id.
	*/  
	bool existe_especie(string id) const;

	/**
	@brief A partir de dos especies calcula la distancia que hay entre ellas.
	\pre Cierto.
	\post El resultado es la distancia entre las especies a menos que una de las dos no exista.
	*/
    double distancia(string id1, string id2);
	  
	/* Lectura y escritura */

	void lee_k();
	
	/**
	@brief Lee por el canal estándar de entrada una especie (par id-gen)
	\pre Cierto.
	\post El resultado es una especie con el ID y gen entrados.
	*/ 
	void lee_especie();
	
	/**
	@brief Crea el cjy_especies.
	\pre Cierto.
	\post El parámetro implícito contiene el conjunto de especies leídos por el canal estándar de entrada.
	*/ 
	void lee_cjt_especies();

    
    void verifica_especie(const string& id);
    
	/**
	@brief Imprime el cjt_especies.
	\pre Cierto.
	\post Se han escrito por el canal estándar de salida las especies del parámetro implícito.
	*/   
	void imprime_cjt_especies() const;

	/**
	@brief Imprime la tabla de distancias entre cada par de especies del conjunto especies si el conjunto no es vacío.
	\pre Cierto.
	\post Se han escrito por el canal estándar de salida la tabla de distancias entre cada par de especies del conjunto especies.
	*/   
	void imprime_tabla_distancias();
    
    void imprime_meros() const;
};

#endif
