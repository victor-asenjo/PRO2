/** @file Cluster.hh
    @brief Especificación de la clase Cluster
*/

#ifndef CLUSTER_HH
#define CLUSTER_HH

#include "BinTree.hh"
#include "Cjt_especies.hh"

using namespace std; 

/**
    @class Cluster
    @brief Tipo de módulo: datos.
    @brief Descripción del tipo: representa un conjunto de clusters que se pueden consultar y modificar sus elementos (de tipo Cjt_especies).
*/

class Cluster
{

private:
    BinTree<Especie> arbol;

public:

    /* Constructoras */

    /**
    @brief Constructora Cjt_cluster.
    \pre Cierto.
    \post El resultado es un conjunto de clusters vacío.
    */
    Cluster();

    /* Destructora */

    /**
    @brief Destructora Cjt_cluster.
    */
    ~Cluster();
   

    /* Modificadoras */
    void inicializa_clusters(Cjt_especies especies);

    void ejecuta_paso_wpgma();
  
    /* Consultoras */
  
    
    /* Lectura y escritura */
    void imprime_cluster();
    void imprime_arbol_filoge();
    void imprime_tabla_distancias();

};

#endif
